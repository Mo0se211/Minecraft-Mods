particle minecraft:heart ~ ~2 ~ 0.4 0.3 0.4 0 4
particle minecraft:dust{color:[0.75,0.05,0.1],scale:1.4} ~ ~1 ~ 0.5 0.6 0.5 0 25
playsound minecraft:entity.generic.drink player @a ~ ~ ~ 0.8 0.6
effect give @s minecraft:regeneration 3 1
