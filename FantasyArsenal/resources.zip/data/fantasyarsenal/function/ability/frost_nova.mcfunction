particle minecraft:snowflake ~ ~1 ~ 1.8 0.8 1.8 0.03 70
particle minecraft:block{block_state:"minecraft:ice"} ~ ~1 ~ 1.5 0.6 1.5 0 40
playsound minecraft:block.glass.break player @a ~ ~ ~ 1 1.4
effect give @e[type=#fantasyarsenal:hostiles,distance=..4.5] minecraft:slowness 4 3
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run data merge entity @s {TicksFrozen:300}
damage @s 2 minecraft:freeze
