particle minecraft:block{block_state:"minecraft:moss_block"} ~ ~0.3 ~ 0.6 0.2 0.6 0 40
particle minecraft:spore_blossom_air ~ ~1 ~ 0.6 0.5 0.6 0 20
playsound minecraft:block.moss.break player @a ~ ~ ~ 1 0.6
