particle minecraft:dust{color:[0.45,0.9,0.2],scale:1.6} ~ ~1 ~ 1.8 0.7 1.8 0 90
playsound minecraft:block.slime_block.break player @a ~ ~ ~ 1 0.7
effect give @e[type=#fantasyarsenal:hostiles,distance=..4.5] minecraft:poison 5 1
