particle minecraft:sonic_boom ~ ~1 ~ 0 0 0 0 1
particle minecraft:sculk_soul ~ ~1 ~ 1.5 0.8 1.5 0.05 40
playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 0.8 1.2
effect give @e[type=#fantasyarsenal:hostiles,distance=..4.5] minecraft:slowness 3 1
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 7 minecraft:sonic_boom
