particle minecraft:flame ~ ~1 ~ 1.5 0.7 1.5 0.08 80
particle minecraft:lava ~ ~1 ~ 1 0.5 1 0 12
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 0.8
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run data merge entity @s {Fire:100s}
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 4 minecraft:on_fire
