particle minecraft:block{block_state:"minecraft:dirt"} ~ ~0.3 ~ 2 0.2 2 0 120
particle minecraft:explosion ~ ~0.5 ~ 1 0.2 1 0 4
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 0.6 1.4
effect give @e[type=#fantasyarsenal:hostiles,distance=..4.5] minecraft:slowness 3 2
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 5 minecraft:generic
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run data merge entity @s {Motion:[0.0,0.55,0.0]}
