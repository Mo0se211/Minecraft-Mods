particle minecraft:block{block_state:"minecraft:amethyst_block"} ~ ~1 ~ 1.5 0.7 1.5 0 70
particle minecraft:end_rod ~ ~1 ~ 1 0.6 1 0.08 20
playsound minecraft:block.amethyst_cluster.break player @a ~ ~ ~ 1 1.2
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 3 minecraft:magic
