particle minecraft:soul ~ ~1 ~ 0.6 0.8 0.6 0.04 25
playsound minecraft:particle.soul_escape player @a ~ ~ ~ 1 0.8
effect give @s minecraft:absorption 10 0
