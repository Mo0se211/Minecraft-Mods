particle minecraft:end_rod ~ ~1 ~ 1.4 1 1.4 0.15 70
particle minecraft:firework ~ ~1 ~ 1 0.8 1 0.1 40
playsound minecraft:entity.firework_rocket.twinkle player @a ~ ~ ~ 1 1
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 4 minecraft:magic
