particle minecraft:soul_fire_flame ~ ~1 ~ 1.5 0.7 1.5 0.07 80
particle minecraft:soul ~ ~1 ~ 1 0.6 1 0.03 20
playsound minecraft:particle.soul_escape player @a ~ ~ ~ 1 0.6
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run data merge entity @s {Fire:80s}
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 4 minecraft:on_fire
