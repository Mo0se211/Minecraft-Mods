particle minecraft:reverse_portal ~ ~1 ~ 1.5 1 1.5 0.2 120
particle minecraft:squid_ink ~ ~1 ~ 1 0.5 1 0.05 30
playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 1 0.6
effect give @e[type=#fantasyarsenal:hostiles,distance=..4.5] minecraft:slowness 3 2
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 5 minecraft:magic
