particle minecraft:large_smoke ~ ~1 ~ 0.5 0.6 0.5 0.02 25
particle minecraft:squid_ink ~ ~1 ~ 0.4 0.5 0.4 0.02 15
playsound minecraft:entity.player.attack.crit player @a ~ ~ ~ 1 0.6
damage @s 4 minecraft:magic
