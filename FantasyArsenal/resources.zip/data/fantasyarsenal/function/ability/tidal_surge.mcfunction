particle minecraft:splash ~ ~1 ~ 1.8 0.6 1.8 0.3 150
particle minecraft:bubble_pop ~ ~1 ~ 1.5 0.8 1.5 0.1 60
playsound minecraft:entity.player.splash.high_speed player @a ~ ~ ~ 1 1
effect give @e[type=#fantasyarsenal:hostiles,distance=..4.5] minecraft:slowness 3 1
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 3 minecraft:drown
