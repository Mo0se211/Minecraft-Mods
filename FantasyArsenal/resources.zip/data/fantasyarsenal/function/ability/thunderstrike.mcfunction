particle minecraft:electric_spark ~ ~1 ~ 1.2 1.5 1.2 0.6 120
particle minecraft:flash ~ ~1 ~ 0 0 0 0 1
playsound minecraft:entity.lightning_bolt.thunder player @a ~ ~ ~ 0.7 1.3
damage @s 5 minecraft:lightning_bolt
execute as @e[type=#fantasyarsenal:hostiles,distance=..4.5] run damage @s 3 minecraft:lightning_bolt
