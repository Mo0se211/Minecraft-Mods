particle minecraft:gust ~ ~0.5 ~ 0.3 0.2 0.3 0 3
playsound minecraft:entity.wind_charge.wind_burst player @a ~ ~ ~ 1 1
