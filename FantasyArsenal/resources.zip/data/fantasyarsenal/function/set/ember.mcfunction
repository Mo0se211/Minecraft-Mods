effect give @s minecraft:fire_resistance 5 0 true
