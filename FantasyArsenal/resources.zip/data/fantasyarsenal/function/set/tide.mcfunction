effect give @s minecraft:water_breathing 5 0 true
effect give @s minecraft:dolphins_grace 5 0 true
