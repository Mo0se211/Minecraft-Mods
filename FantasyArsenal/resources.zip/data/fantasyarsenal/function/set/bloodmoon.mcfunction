effect give @s minecraft:regeneration 5 0 true
