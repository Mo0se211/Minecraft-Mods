effect give @s minecraft:haste 5 1 true
