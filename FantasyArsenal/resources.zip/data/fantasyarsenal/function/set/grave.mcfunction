effect give @s minecraft:strength 5 0 true
effect clear @s minecraft:wither
