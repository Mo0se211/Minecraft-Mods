effect give @s minecraft:jump_boost 5 1 true
