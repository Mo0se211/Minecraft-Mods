effect give @s minecraft:fire_resistance 5 0 true
effect give @s minecraft:speed 5 0 true
