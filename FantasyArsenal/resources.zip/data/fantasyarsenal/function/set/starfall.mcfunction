effect give @s minecraft:slow_falling 2 0 true
