effect give @s minecraft:night_vision 15 0 true
effect clear @s minecraft:darkness
