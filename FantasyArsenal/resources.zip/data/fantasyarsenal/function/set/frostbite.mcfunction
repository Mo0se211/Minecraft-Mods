fill ~-2 ~-1 ~-2 ~2 ~-1 ~2 minecraft:frosted_ice replace minecraft:water[level=0]
effect clear @s minecraft:slowness
