effect give @s minecraft:invisibility 2 0 true
