effect give @s minecraft:resistance 5 0 true
effect give @s minecraft:strength 5 0 true
effect clear @s minecraft:darkness
