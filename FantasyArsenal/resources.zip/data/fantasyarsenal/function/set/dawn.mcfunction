effect give @s minecraft:resistance 5 0 true
