clear @s minecraft:netherite_axe[minecraft:custom_data={fa_token:"bloodmoon_reaver",fa_t:1b}] 1
loot give @s loot fantasyarsenal:weapons/bloodmoon_reaver
advancement revoke @s only fantasyarsenal:token/bloodmoon_reaver
execute if items entity @s container.* minecraft:netherite_axe[minecraft:custom_data={fa_token:"bloodmoon_reaver",fa_t:1b}] run function fantasyarsenal:token/bloodmoon_reaver
execute if items entity @s armor.* minecraft:netherite_axe[minecraft:custom_data={fa_token:"bloodmoon_reaver",fa_t:1b}] run function fantasyarsenal:token/bloodmoon_reaver
execute if items entity @s weapon.offhand minecraft:netherite_axe[minecraft:custom_data={fa_token:"bloodmoon_reaver",fa_t:1b}] run function fantasyarsenal:token/bloodmoon_reaver
