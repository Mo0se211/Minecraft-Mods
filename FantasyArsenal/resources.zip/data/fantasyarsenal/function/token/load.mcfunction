schedule function fantasyarsenal:token/sweep 10t replace
