clear @s minecraft:netherite_sword[minecraft:custom_data={fa_token:"thornroot_glaive",fa_t:1b}] 1
loot give @s loot fantasyarsenal:weapons/thornroot_glaive
advancement revoke @s only fantasyarsenal:token/thornroot_glaive
execute if items entity @s container.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"thornroot_glaive",fa_t:1b}] run function fantasyarsenal:token/thornroot_glaive
execute if items entity @s armor.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"thornroot_glaive",fa_t:1b}] run function fantasyarsenal:token/thornroot_glaive
execute if items entity @s weapon.offhand minecraft:netherite_sword[minecraft:custom_data={fa_token:"thornroot_glaive",fa_t:1b}] run function fantasyarsenal:token/thornroot_glaive
