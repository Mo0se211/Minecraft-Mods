clear @s minecraft:bow[minecraft:custom_data={fa_token:"starfall_bow",fa_t:1b}] 1
loot give @s loot fantasyarsenal:weapons/starfall_bow
advancement revoke @s only fantasyarsenal:token/starfall_bow
execute if items entity @s container.* minecraft:bow[minecraft:custom_data={fa_token:"starfall_bow",fa_t:1b}] run function fantasyarsenal:token/starfall_bow
execute if items entity @s armor.* minecraft:bow[minecraft:custom_data={fa_token:"starfall_bow",fa_t:1b}] run function fantasyarsenal:token/starfall_bow
execute if items entity @s weapon.offhand minecraft:bow[minecraft:custom_data={fa_token:"starfall_bow",fa_t:1b}] run function fantasyarsenal:token/starfall_bow
