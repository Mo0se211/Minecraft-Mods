clear @s minecraft:netherite_boots[minecraft:custom_data={fa_token:"dawn_boots",fa_t:1b}] 1
loot give @s loot fantasyarsenal:armor/dawn_boots
advancement revoke @s only fantasyarsenal:token/dawn_boots
execute if items entity @s container.* minecraft:netherite_boots[minecraft:custom_data={fa_token:"dawn_boots",fa_t:1b}] run function fantasyarsenal:token/dawn_boots
execute if items entity @s armor.* minecraft:netherite_boots[minecraft:custom_data={fa_token:"dawn_boots",fa_t:1b}] run function fantasyarsenal:token/dawn_boots
execute if items entity @s weapon.offhand minecraft:netherite_boots[minecraft:custom_data={fa_token:"dawn_boots",fa_t:1b}] run function fantasyarsenal:token/dawn_boots
