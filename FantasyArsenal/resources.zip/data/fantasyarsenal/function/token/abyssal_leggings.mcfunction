clear @s minecraft:netherite_leggings[minecraft:custom_data={fa_token:"abyssal_leggings",fa_t:1b}] 1
loot give @s loot fantasyarsenal:armor/abyssal_leggings
advancement revoke @s only fantasyarsenal:token/abyssal_leggings
execute if items entity @s container.* minecraft:netherite_leggings[minecraft:custom_data={fa_token:"abyssal_leggings",fa_t:1b}] run function fantasyarsenal:token/abyssal_leggings
execute if items entity @s armor.* minecraft:netherite_leggings[minecraft:custom_data={fa_token:"abyssal_leggings",fa_t:1b}] run function fantasyarsenal:token/abyssal_leggings
execute if items entity @s weapon.offhand minecraft:netherite_leggings[minecraft:custom_data={fa_token:"abyssal_leggings",fa_t:1b}] run function fantasyarsenal:token/abyssal_leggings
