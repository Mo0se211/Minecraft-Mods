execute as @a if items entity @s container.* *[minecraft:custom_data~{fa_t:1b}] run function fantasyarsenal:token/convert_all
execute as @a if items entity @s armor.* *[minecraft:custom_data~{fa_t:1b}] run function fantasyarsenal:token/convert_all
schedule function fantasyarsenal:token/sweep 10t replace
