clear @s minecraft:diamond_sword[minecraft:custom_data={fa_token:"shadowstep_dagger",fa_t:1b}] 1
loot give @s loot fantasyarsenal:weapons/shadowstep_dagger
advancement revoke @s only fantasyarsenal:token/shadowstep_dagger
execute if items entity @s container.* minecraft:diamond_sword[minecraft:custom_data={fa_token:"shadowstep_dagger",fa_t:1b}] run function fantasyarsenal:token/shadowstep_dagger
execute if items entity @s armor.* minecraft:diamond_sword[minecraft:custom_data={fa_token:"shadowstep_dagger",fa_t:1b}] run function fantasyarsenal:token/shadowstep_dagger
execute if items entity @s weapon.offhand minecraft:diamond_sword[minecraft:custom_data={fa_token:"shadowstep_dagger",fa_t:1b}] run function fantasyarsenal:token/shadowstep_dagger
