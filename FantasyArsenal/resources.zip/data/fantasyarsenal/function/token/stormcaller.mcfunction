clear @s minecraft:netherite_sword[minecraft:custom_data={fa_token:"stormcaller",fa_t:1b}] 1
loot give @s loot fantasyarsenal:weapons/stormcaller
advancement revoke @s only fantasyarsenal:token/stormcaller
execute if items entity @s container.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"stormcaller",fa_t:1b}] run function fantasyarsenal:token/stormcaller
execute if items entity @s armor.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"stormcaller",fa_t:1b}] run function fantasyarsenal:token/stormcaller
execute if items entity @s weapon.offhand minecraft:netherite_sword[minecraft:custom_data={fa_token:"stormcaller",fa_t:1b}] run function fantasyarsenal:token/stormcaller
