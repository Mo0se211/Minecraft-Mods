clear @s minecraft:netherite_leggings[minecraft:custom_data={fa_token:"bloodmoon_leggings",fa_t:1b}] 1
loot give @s loot fantasyarsenal:armor/bloodmoon_leggings
advancement revoke @s only fantasyarsenal:token/bloodmoon_leggings
execute if items entity @s container.* minecraft:netherite_leggings[minecraft:custom_data={fa_token:"bloodmoon_leggings",fa_t:1b}] run function fantasyarsenal:token/bloodmoon_leggings
execute if items entity @s armor.* minecraft:netherite_leggings[minecraft:custom_data={fa_token:"bloodmoon_leggings",fa_t:1b}] run function fantasyarsenal:token/bloodmoon_leggings
execute if items entity @s weapon.offhand minecraft:netherite_leggings[minecraft:custom_data={fa_token:"bloodmoon_leggings",fa_t:1b}] run function fantasyarsenal:token/bloodmoon_leggings
