clear @s minecraft:netherite_helmet[minecraft:custom_data={fa_token:"prism_helmet",fa_t:1b}] 1
loot give @s loot fantasyarsenal:armor/prism_helmet
advancement revoke @s only fantasyarsenal:token/prism_helmet
execute if items entity @s container.* minecraft:netherite_helmet[minecraft:custom_data={fa_token:"prism_helmet",fa_t:1b}] run function fantasyarsenal:token/prism_helmet
execute if items entity @s armor.* minecraft:netherite_helmet[minecraft:custom_data={fa_token:"prism_helmet",fa_t:1b}] run function fantasyarsenal:token/prism_helmet
execute if items entity @s weapon.offhand minecraft:netherite_helmet[minecraft:custom_data={fa_token:"prism_helmet",fa_t:1b}] run function fantasyarsenal:token/prism_helmet
