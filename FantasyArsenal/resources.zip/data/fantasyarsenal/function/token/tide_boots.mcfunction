clear @s minecraft:netherite_boots[minecraft:custom_data={fa_token:"tide_boots",fa_t:1b}] 1
loot give @s loot fantasyarsenal:armor/tide_boots
advancement revoke @s only fantasyarsenal:token/tide_boots
execute if items entity @s container.* minecraft:netherite_boots[minecraft:custom_data={fa_token:"tide_boots",fa_t:1b}] run function fantasyarsenal:token/tide_boots
execute if items entity @s armor.* minecraft:netherite_boots[minecraft:custom_data={fa_token:"tide_boots",fa_t:1b}] run function fantasyarsenal:token/tide_boots
execute if items entity @s weapon.offhand minecraft:netherite_boots[minecraft:custom_data={fa_token:"tide_boots",fa_t:1b}] run function fantasyarsenal:token/tide_boots
