clear @s minecraft:netherite_chestplate[minecraft:custom_data={fa_token:"quake_chestplate",fa_t:1b}] 1
loot give @s loot fantasyarsenal:armor/quake_chestplate
advancement revoke @s only fantasyarsenal:token/quake_chestplate
execute if items entity @s container.* minecraft:netherite_chestplate[minecraft:custom_data={fa_token:"quake_chestplate",fa_t:1b}] run function fantasyarsenal:token/quake_chestplate
execute if items entity @s armor.* minecraft:netherite_chestplate[minecraft:custom_data={fa_token:"quake_chestplate",fa_t:1b}] run function fantasyarsenal:token/quake_chestplate
execute if items entity @s weapon.offhand minecraft:netherite_chestplate[minecraft:custom_data={fa_token:"quake_chestplate",fa_t:1b}] run function fantasyarsenal:token/quake_chestplate
