clear @s minecraft:netherite_sword[minecraft:custom_data={fa_token:"prismshard",fa_t:1b}] 1
loot give @s loot fantasyarsenal:weapons/prismshard
advancement revoke @s only fantasyarsenal:token/prismshard
execute if items entity @s container.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"prismshard",fa_t:1b}] run function fantasyarsenal:token/prismshard
execute if items entity @s armor.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"prismshard",fa_t:1b}] run function fantasyarsenal:token/prismshard
execute if items entity @s weapon.offhand minecraft:netherite_sword[minecraft:custom_data={fa_token:"prismshard",fa_t:1b}] run function fantasyarsenal:token/prismshard
