clear @s minecraft:netherite_sword[minecraft:custom_data={fa_token:"gravemourne",fa_t:1b}] 1
loot give @s loot fantasyarsenal:weapons/gravemourne
advancement revoke @s only fantasyarsenal:token/gravemourne
execute if items entity @s container.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"gravemourne",fa_t:1b}] run function fantasyarsenal:token/gravemourne
execute if items entity @s armor.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"gravemourne",fa_t:1b}] run function fantasyarsenal:token/gravemourne
execute if items entity @s weapon.offhand minecraft:netherite_sword[minecraft:custom_data={fa_token:"gravemourne",fa_t:1b}] run function fantasyarsenal:token/gravemourne
