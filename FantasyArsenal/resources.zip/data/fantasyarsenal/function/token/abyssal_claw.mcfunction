clear @s minecraft:netherite_sword[minecraft:custom_data={fa_token:"abyssal_claw",fa_t:1b}] 1
loot give @s loot fantasyarsenal:weapons/abyssal_claw
advancement revoke @s only fantasyarsenal:token/abyssal_claw
execute if items entity @s container.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"abyssal_claw",fa_t:1b}] run function fantasyarsenal:token/abyssal_claw
execute if items entity @s armor.* minecraft:netherite_sword[minecraft:custom_data={fa_token:"abyssal_claw",fa_t:1b}] run function fantasyarsenal:token/abyssal_claw
execute if items entity @s weapon.offhand minecraft:netherite_sword[minecraft:custom_data={fa_token:"abyssal_claw",fa_t:1b}] run function fantasyarsenal:token/abyssal_claw
