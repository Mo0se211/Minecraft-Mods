particle minecraft:dust{color:[0.75,0.05,0.1],scale:1.1} ~ ~1 ~ 0.3 0.5 0.3 0 10
