particle minecraft:dust{color:[0.88,0.19,0.23],scale:0.7} ~ ~0.08 ~ 0.18 0.02 0.18 0 1
