particle minecraft:falling_dust{block_state:"minecraft:gravel"} ~ ~0.7 ~ 0.3 0.25 0.3 0 1
