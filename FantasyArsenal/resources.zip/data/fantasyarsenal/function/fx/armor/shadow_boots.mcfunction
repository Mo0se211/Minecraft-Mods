particle minecraft:smoke ~ ~0.08 ~ 0.18 0.02 0.18 0.003 1
