particle minecraft:sculk_soul ~ ~1 ~ 0.9 0.9 0.9 0.04 30
playsound minecraft:block.sculk_shrieker.shriek player @a ~ ~ ~ 0.3 1.6
