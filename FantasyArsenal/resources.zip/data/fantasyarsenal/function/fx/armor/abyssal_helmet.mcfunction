particle minecraft:reverse_portal ~ ~2.15 ~ 0.25 0.12 0.25 0.02 2
