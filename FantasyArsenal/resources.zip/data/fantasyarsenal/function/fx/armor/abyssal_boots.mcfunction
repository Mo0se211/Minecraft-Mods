particle minecraft:reverse_portal ~ ~0.08 ~ 0.18 0.02 0.18 0.01 1
