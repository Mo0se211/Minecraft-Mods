particle minecraft:falling_spore_blossom ~ ~0.7 ~ 0.3 0.25 0.3 0 1
