particle minecraft:spore_blossom_air ^ ^1.25 ^0.32 0.12 0.15 0.12 0 2
