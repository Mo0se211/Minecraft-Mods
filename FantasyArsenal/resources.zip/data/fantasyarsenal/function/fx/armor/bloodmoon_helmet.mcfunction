particle minecraft:dust{color:[0.17,0.11,0.13],scale:0.9} ~ ~2.15 ~ 0.25 0.12 0.25 0 1
