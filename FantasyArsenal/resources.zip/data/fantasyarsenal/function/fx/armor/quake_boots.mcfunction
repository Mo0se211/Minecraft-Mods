particle minecraft:block{block_state:"minecraft:dirt"} ~ ~0.08 ~ 0.18 0.02 0.18 0 3
