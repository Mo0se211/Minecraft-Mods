particle minecraft:snowflake ~ ~0.08 ~ 0.18 0.02 0.18 0.01 1
particle minecraft:dust{color:[0.84,0.90,0.93],scale:0.8} ~ ~0.08 ~ 0.18 0.02 0.18 0 1
