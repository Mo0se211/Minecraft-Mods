particle minecraft:splash ~ ~0.08 ~ 0.18 0.02 0.18 0.1 3
