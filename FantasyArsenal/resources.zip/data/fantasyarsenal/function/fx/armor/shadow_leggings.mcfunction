particle minecraft:ash ~ ~0.7 ~ 0.3 0.25 0.3 0 3
