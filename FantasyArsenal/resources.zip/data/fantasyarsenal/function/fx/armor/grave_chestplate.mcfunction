particle minecraft:dust{color:[0.50,1.00,0.69],scale:0.8} ^ ^1.25 ^0.32 0.12 0.15 0.12 0 2
