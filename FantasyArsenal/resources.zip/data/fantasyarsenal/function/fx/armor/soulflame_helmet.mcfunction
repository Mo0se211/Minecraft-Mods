particle minecraft:soul_fire_flame ~ ~2.15 ~ 0.25 0.12 0.25 0.005 1
