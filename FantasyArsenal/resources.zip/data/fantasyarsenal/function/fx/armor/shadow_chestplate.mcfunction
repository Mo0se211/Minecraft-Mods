particle minecraft:dust{color:[0.79,0.49,1.00],scale:0.7} ^ ^1.25 ^0.32 0.12 0.15 0.12 0 1
