particle minecraft:wax_off ~ ~0.7 ~ 0.3 0.25 0.3 0 1
