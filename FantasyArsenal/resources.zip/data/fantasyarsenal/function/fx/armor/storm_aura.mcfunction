particle minecraft:electric_spark ~ ~1 ~ 0.9 0.9 0.9 0.6 50
playsound minecraft:entity.lightning_bolt.impact player @a ~ ~ ~ 0.25 1.8
