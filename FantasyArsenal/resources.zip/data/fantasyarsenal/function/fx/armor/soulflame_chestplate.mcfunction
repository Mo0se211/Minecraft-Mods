particle minecraft:soul_fire_flame ^ ^1.25 ^0.32 0.12 0.15 0.12 0.003 1
