particle minecraft:small_flame ~ ~0.08 ~ 0.18 0.02 0.18 0.005 1
particle minecraft:smoke ~ ~0.08 ~ 0.18 0.02 0.18 0.01 1
