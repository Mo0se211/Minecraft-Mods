particle minecraft:warped_spore ~ ~1 ~ 0.9 0.9 0.9 0 30
particle minecraft:dust{color:[0.64,0.88,0.30],scale:1.2} ~ ~1 ~ 0.9 0.9 0.9 0 20
