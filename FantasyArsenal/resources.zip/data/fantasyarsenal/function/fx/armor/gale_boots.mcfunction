particle minecraft:cloud ~ ~0.08 ~ 0.18 0.02 0.18 0.01 1
