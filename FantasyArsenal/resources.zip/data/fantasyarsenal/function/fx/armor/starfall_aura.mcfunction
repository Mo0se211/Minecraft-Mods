particle minecraft:firework ~ ~1 ~ 0.9 0.9 0.9 0.06 30
playsound minecraft:entity.firework_rocket.twinkle_far player @a ~ ~ ~ 0.5 1.2
