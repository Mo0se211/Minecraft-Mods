particle minecraft:dust{color:[0.63,0.60,0.77],scale:0.7} ~ ~0.08 ~ 0.18 0.02 0.18 0 2
