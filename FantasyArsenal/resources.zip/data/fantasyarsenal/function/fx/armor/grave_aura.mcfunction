particle minecraft:sculk_soul ~ ~1 ~ 0.9 0.9 0.9 0.03 25
playsound minecraft:particle.soul_escape player @a ~ ~ ~ 0.6 0.8
