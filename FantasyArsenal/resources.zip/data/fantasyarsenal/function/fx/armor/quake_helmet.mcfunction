particle minecraft:falling_dust{block_state:"minecraft:dirt"} ~ ~2.15 ~ 0.25 0.12 0.25 0 1
