particle minecraft:falling_spore_blossom ~ ~2.15 ~ 0.25 0.12 0.25 0 1
