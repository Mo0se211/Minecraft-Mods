particle minecraft:dust{color:[0.29,0.37,0.18],scale:0.8} ~ ~0.08 ~ 0.18 0.02 0.18 0 1
