particle minecraft:small_gust ~ ~0.5 ~ 0.5 0.2 0.5 0 3
playsound minecraft:entity.breeze.idle_ground player @a ~ ~ ~ 0.4 1.4
