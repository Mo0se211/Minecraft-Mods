particle minecraft:electric_spark ~ ~0.7 ~ 0.3 0.25 0.3 0.2 1
