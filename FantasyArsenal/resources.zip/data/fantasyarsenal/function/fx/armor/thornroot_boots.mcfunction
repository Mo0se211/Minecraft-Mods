particle minecraft:composter ~ ~0.08 ~ 0.18 0.02 0.18 0 2
