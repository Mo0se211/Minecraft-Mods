particle minecraft:end_rod ~ ~1 ~ 0.9 0.9 0.9 0.05 30
playsound minecraft:block.beacon.ambient player @a ~ ~ ~ 0.4 1.8
