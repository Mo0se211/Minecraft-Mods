particle minecraft:block{block_state:"minecraft:amethyst_block"} ~ ~1 ~ 0.9 0.9 0.9 0 30
playsound minecraft:block.amethyst_block.resonate player @a ~ ~ ~ 0.6 1.2
