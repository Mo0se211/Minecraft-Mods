particle minecraft:dust{color:[0.85,0.60,1.00],scale:0.7} ~ ~2.15 ~ 0.25 0.12 0.25 0 2
