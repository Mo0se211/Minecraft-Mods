particle minecraft:bubble_pop ^ ^1.25 ^0.32 0.12 0.15 0.12 0.02 2
