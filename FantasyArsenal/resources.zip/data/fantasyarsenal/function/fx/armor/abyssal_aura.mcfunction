particle minecraft:reverse_portal ~ ~1 ~ 0.9 0.9 0.9 0.1 60
particle minecraft:squid_ink ~ ~1 ~ 0.9 0.9 0.9 0.01 6
