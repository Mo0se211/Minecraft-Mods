particle minecraft:white_ash ~ ~2.15 ~ 0.25 0.12 0.25 0 3
