particle minecraft:cherry_leaves ~ ~1 ~ 0.9 0.9 0.9 0 25
playsound minecraft:block.azalea_leaves.break player @a ~ ~ ~ 0.6 1
