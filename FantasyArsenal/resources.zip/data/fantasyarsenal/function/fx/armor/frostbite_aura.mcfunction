particle minecraft:snowflake ~ ~1 ~ 0.9 0.9 0.9 0.06 40
playsound minecraft:block.amethyst_block.chime player @a ~ ~ ~ 0.5 1.6
