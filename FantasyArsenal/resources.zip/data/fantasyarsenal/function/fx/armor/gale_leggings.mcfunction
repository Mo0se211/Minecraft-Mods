particle minecraft:cloud ~ ~0.7 ~ 0.3 0.25 0.3 0.01 1
