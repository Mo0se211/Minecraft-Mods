particle minecraft:soul_fire_flame ~ ~0.08 ~ 0.18 0.02 0.18 0.003 1
