particle minecraft:small_flame ~ ~2.15 ~ 0.25 0.12 0.25 0.01 1
