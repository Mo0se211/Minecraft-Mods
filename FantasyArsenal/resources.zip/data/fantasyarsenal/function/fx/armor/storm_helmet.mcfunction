particle minecraft:electric_spark ~ ~2.15 ~ 0.25 0.12 0.25 0.3 2
