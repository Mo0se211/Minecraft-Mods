particle minecraft:soul_fire_flame ~ ~1 ~ 0.9 0.9 0.9 0.05 40
playsound minecraft:particle.soul_escape player @a ~ ~ ~ 0.6 1.2
