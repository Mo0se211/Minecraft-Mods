particle minecraft:sculk_charge_pop ~ ~0.08 ~ 0.18 0.02 0.18 0.01 2
