particle minecraft:dust{color:[0.88,0.19,0.23],scale:0.9} ^ ^1.25 ^0.32 0.12 0.15 0.12 0 2
