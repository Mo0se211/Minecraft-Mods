particle minecraft:dust{color:[0.64,0.88,0.30],scale:0.8} ~ ~2.15 ~ 0.25 0.12 0.25 0 1
