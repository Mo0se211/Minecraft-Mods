particle minecraft:flame ~ ~1 ~ 0.9 0.9 0.9 0.05 40
particle minecraft:lava ~ ~1 ~ 0.9 0.9 0.9 0 4
