particle minecraft:firework ^ ^1.25 ^0.32 0.12 0.15 0.12 0.01 1
