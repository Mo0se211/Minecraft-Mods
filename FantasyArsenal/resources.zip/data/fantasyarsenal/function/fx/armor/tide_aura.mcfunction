particle minecraft:bubble_pop ~ ~1 ~ 0.9 0.9 0.9 0.05 40
particle minecraft:dolphin ~ ~1 ~ 0.9 0.9 0.9 0.05 20
