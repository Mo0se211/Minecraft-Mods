particle minecraft:wax_on ^ ^1.25 ^0.32 0.12 0.15 0.12 0 1
