particle minecraft:soul ~ ~0.08 ~ 0.18 0.02 0.18 0.005 1
