particle minecraft:large_smoke ~ ~1 ~ 0.9 0.9 0.9 0.01 20
particle minecraft:dust{color:[0.79,0.49,1.00],scale:1.0} ~ ~1 ~ 0.9 0.9 0.9 0 10
