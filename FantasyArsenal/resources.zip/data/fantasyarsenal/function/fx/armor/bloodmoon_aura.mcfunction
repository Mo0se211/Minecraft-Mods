particle minecraft:dust{color:[0.88,0.19,0.23],scale:1.4} ~ ~1 ~ 0.9 0.9 0.9 0 40
particle minecraft:crimson_spore ~ ~1 ~ 0.9 0.9 0.9 0 30
