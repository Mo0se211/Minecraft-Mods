particle minecraft:dust{color:[0.62,0.91,1.00],scale:1.0} ^ ^1.25 ^0.32 0.12 0.15 0.12 0 2
