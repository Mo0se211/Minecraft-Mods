particle minecraft:falling_dust{block_state:"minecraft:stone"} ^ ^1.25 ^0.32 0.12 0.15 0.12 0 1
