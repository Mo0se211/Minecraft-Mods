particle minecraft:block{block_state:"minecraft:stone"} ~ ~0.2 ~ 1.2 0.1 1.2 0 40
playsound minecraft:block.stone.break player @a ~ ~ ~ 0.6 0.6
