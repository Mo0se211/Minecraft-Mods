particle minecraft:electric_spark ~ ~0.08 ~ 0.18 0.02 0.18 0.2 2
