particle minecraft:end_rod ~ ~1 ~ 0.3 0.5 0.3 0.05 8
particle minecraft:firework ~ ~1 ~ 0.2 0.3 0.2 0.05 4
