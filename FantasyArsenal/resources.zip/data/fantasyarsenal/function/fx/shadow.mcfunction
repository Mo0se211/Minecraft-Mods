particle minecraft:smoke ~ ~1 ~ 0.3 0.5 0.3 0.02 10
