particle minecraft:dust{color:[0.8,0.45,1.0],scale:1.0} ~ ~1 ~ 0.3 0.5 0.3 0 10
