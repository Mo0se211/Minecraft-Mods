particle minecraft:spore_blossom_air ~ ~1 ~ 0.4 0.5 0.4 0 8
