particle minecraft:cloud ~ ~1 ~ 0.3 0.4 0.3 0.03 6
