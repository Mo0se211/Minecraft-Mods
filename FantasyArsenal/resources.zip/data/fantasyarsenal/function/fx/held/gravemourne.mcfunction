execute rotated ~ 0 run particle minecraft:soul ^-0.42 ^1.45 ^0.75 0.06 0.12 0.06 0.005 1
execute rotated ~ 0 run particle minecraft:dust{color:[0.50,1.00,0.69],scale:0.7} ^-0.38 ^1.15 ^0.55 0.08 0.18 0.08 0 1
