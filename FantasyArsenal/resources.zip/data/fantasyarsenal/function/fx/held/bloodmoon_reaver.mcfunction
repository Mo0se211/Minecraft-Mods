execute rotated ~ 0 run particle minecraft:dust{color:[0.79,0.19,0.24],scale:0.9} ^-0.42 ^1.45 ^0.75 0.06 0.12 0.06 0 1
execute rotated ~ 0 run particle minecraft:crimson_spore ^-0.38 ^1.15 ^0.55 0.08 0.18 0.08 0 1
