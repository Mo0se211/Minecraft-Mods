execute rotated ~ 0 run particle minecraft:falling_dust{block_state:"minecraft:dirt"} ^-0.42 ^1.45 ^0.75 0.06 0.12 0.06 0 1
execute rotated ~ 0 run particle minecraft:dust{color:[1.00,0.71,0.25],scale:0.6} ^-0.38 ^1.15 ^0.55 0.08 0.18 0.08 0 1
