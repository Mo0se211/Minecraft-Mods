execute rotated ~ 0 run particle minecraft:end_rod ^-0.42 ^1.45 ^0.75 0.06 0.12 0.06 0.003 1
execute rotated ~ 0 run particle minecraft:wax_on ^-0.38 ^1.15 ^0.55 0.08 0.18 0.08 0 1
