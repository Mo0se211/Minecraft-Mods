execute rotated ~ 0 run particle minecraft:white_ash ^-0.42 ^1.45 ^0.75 0.06 0.12 0.06 0 3
execute rotated ~ 0 run particle minecraft:dust{color:[0.90,0.96,0.94],scale:0.6} ^-0.38 ^1.15 ^0.55 0.08 0.18 0.08 0 1
