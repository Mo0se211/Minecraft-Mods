execute rotated ~ 0 run particle minecraft:sculk_soul ^-0.42 ^1.45 ^0.75 0.06 0.12 0.06 0.005 1
execute rotated ~ 0 run particle minecraft:sculk_charge_pop ^-0.38 ^1.15 ^0.55 0.08 0.18 0.08 0.01 1
