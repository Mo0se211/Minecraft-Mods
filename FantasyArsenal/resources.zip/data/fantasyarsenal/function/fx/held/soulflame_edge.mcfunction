execute rotated ~ 0 run particle minecraft:soul_fire_flame ^-0.42 ^1.45 ^0.75 0.06 0.12 0.06 0.004 1
