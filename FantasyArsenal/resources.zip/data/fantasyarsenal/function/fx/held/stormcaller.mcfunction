execute rotated ~ 0 run particle minecraft:electric_spark ^-0.42 ^1.45 ^0.75 0.06 0.12 0.06 0.15 2
