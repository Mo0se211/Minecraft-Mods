execute rotated ~ 0 run particle minecraft:smoke ^-0.38 ^1.15 ^0.55 0.08 0.18 0.08 0.003 1
execute rotated ~ 0 run particle minecraft:dust{color:[0.69,0.35,1.00],scale:0.6} ^-0.38 ^1.15 ^0.55 0.08 0.18 0.08 0 1
