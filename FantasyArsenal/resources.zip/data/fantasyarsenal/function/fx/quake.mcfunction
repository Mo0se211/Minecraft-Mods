particle minecraft:block{block_state:"minecraft:dirt"} ~ ~0.2 ~ 0.4 0.1 0.4 0 12
