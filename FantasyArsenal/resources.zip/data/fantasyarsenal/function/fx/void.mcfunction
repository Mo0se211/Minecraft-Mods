particle minecraft:reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.05 12
