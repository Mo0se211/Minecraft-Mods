particle minecraft:dust{color:[0.45,0.9,0.2],scale:1.0} ~ ~1 ~ 0.3 0.5 0.3 0 10
