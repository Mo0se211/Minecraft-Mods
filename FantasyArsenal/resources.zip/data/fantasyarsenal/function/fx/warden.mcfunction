particle minecraft:sculk_soul ~ ~1 ~ 0.3 0.5 0.3 0.02 6
