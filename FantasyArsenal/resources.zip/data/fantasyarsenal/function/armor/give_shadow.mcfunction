loot give @s loot fantasyarsenal:armor/shadow_helmet
loot give @s loot fantasyarsenal:armor/shadow_chestplate
loot give @s loot fantasyarsenal:armor/shadow_leggings
loot give @s loot fantasyarsenal:armor/shadow_boots
