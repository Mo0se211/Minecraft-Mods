loot give @s loot fantasyarsenal:armor/starfall_helmet
loot give @s loot fantasyarsenal:armor/starfall_chestplate
loot give @s loot fantasyarsenal:armor/starfall_leggings
loot give @s loot fantasyarsenal:armor/starfall_boots
