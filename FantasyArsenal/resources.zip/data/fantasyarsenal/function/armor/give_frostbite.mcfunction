loot give @s loot fantasyarsenal:armor/frostbite_helmet
loot give @s loot fantasyarsenal:armor/frostbite_chestplate
loot give @s loot fantasyarsenal:armor/frostbite_leggings
loot give @s loot fantasyarsenal:armor/frostbite_boots
