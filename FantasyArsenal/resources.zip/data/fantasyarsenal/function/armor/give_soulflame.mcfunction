loot give @s loot fantasyarsenal:armor/soulflame_helmet
loot give @s loot fantasyarsenal:armor/soulflame_chestplate
loot give @s loot fantasyarsenal:armor/soulflame_leggings
loot give @s loot fantasyarsenal:armor/soulflame_boots
