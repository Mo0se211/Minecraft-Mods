loot give @s loot fantasyarsenal:armor/ember_helmet
loot give @s loot fantasyarsenal:armor/ember_chestplate
loot give @s loot fantasyarsenal:armor/ember_leggings
loot give @s loot fantasyarsenal:armor/ember_boots
