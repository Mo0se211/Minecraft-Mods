loot give @s loot fantasyarsenal:armor/prism_helmet
loot give @s loot fantasyarsenal:armor/prism_chestplate
loot give @s loot fantasyarsenal:armor/prism_leggings
loot give @s loot fantasyarsenal:armor/prism_boots
