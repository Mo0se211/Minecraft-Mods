loot give @s loot fantasyarsenal:armor/gale_helmet
loot give @s loot fantasyarsenal:armor/gale_chestplate
loot give @s loot fantasyarsenal:armor/gale_leggings
loot give @s loot fantasyarsenal:armor/gale_boots
