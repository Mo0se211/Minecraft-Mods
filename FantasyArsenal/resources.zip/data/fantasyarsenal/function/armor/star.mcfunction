particle minecraft:end_rod ~ ~1 ~ 0.4 0.6 0.4 0.05 15
playsound minecraft:entity.firework_rocket.twinkle player @a ~ ~ ~ 0.6 1.3
damage @s 2 minecraft:magic
