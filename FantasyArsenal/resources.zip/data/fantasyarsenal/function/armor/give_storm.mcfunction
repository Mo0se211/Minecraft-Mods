loot give @s loot fantasyarsenal:armor/storm_helmet
loot give @s loot fantasyarsenal:armor/storm_chestplate
loot give @s loot fantasyarsenal:armor/storm_leggings
loot give @s loot fantasyarsenal:armor/storm_boots
