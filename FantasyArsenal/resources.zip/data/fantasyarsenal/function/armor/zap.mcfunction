particle minecraft:electric_spark ~ ~1 ~ 0.4 0.6 0.4 0.4 25
playsound minecraft:entity.lightning_bolt.impact player @a ~ ~ ~ 0.6 1.5
damage @s 3 minecraft:lightning_bolt
