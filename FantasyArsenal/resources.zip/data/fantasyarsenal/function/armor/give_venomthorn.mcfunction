loot give @s loot fantasyarsenal:armor/venomthorn_helmet
loot give @s loot fantasyarsenal:armor/venomthorn_chestplate
loot give @s loot fantasyarsenal:armor/venomthorn_leggings
loot give @s loot fantasyarsenal:armor/venomthorn_boots
