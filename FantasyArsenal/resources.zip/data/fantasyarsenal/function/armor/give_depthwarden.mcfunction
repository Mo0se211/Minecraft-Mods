loot give @s loot fantasyarsenal:armor/depthwarden_helmet
loot give @s loot fantasyarsenal:armor/depthwarden_chestplate
loot give @s loot fantasyarsenal:armor/depthwarden_leggings
loot give @s loot fantasyarsenal:armor/depthwarden_boots
