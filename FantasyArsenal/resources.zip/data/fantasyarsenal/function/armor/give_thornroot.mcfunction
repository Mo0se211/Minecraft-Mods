loot give @s loot fantasyarsenal:armor/thornroot_helmet
loot give @s loot fantasyarsenal:armor/thornroot_chestplate
loot give @s loot fantasyarsenal:armor/thornroot_leggings
loot give @s loot fantasyarsenal:armor/thornroot_boots
