loot give @s loot fantasyarsenal:armor/quake_helmet
loot give @s loot fantasyarsenal:armor/quake_chestplate
loot give @s loot fantasyarsenal:armor/quake_leggings
loot give @s loot fantasyarsenal:armor/quake_boots
