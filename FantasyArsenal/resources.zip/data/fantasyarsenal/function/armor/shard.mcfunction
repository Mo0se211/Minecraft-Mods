particle minecraft:block{block_state:"minecraft:amethyst_block"} ~ ~1 ~ 0.4 0.5 0.4 0 25
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 1 1.2
damage @s 2 minecraft:magic
