loot give @s loot fantasyarsenal:armor/bloodmoon_helmet
loot give @s loot fantasyarsenal:armor/bloodmoon_chestplate
loot give @s loot fantasyarsenal:armor/bloodmoon_leggings
loot give @s loot fantasyarsenal:armor/bloodmoon_boots
