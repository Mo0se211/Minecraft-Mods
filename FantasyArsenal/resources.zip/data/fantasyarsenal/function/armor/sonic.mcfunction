particle minecraft:sonic_boom ~ ~1 ~ 0 0 0 0 1
playsound minecraft:entity.warden.sonic_charge player @a ~ ~ ~ 0.6 1.4
damage @s 3 minecraft:sonic_boom
