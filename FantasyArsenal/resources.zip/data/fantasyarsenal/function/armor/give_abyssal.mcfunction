loot give @s loot fantasyarsenal:armor/abyssal_helmet
loot give @s loot fantasyarsenal:armor/abyssal_chestplate
loot give @s loot fantasyarsenal:armor/abyssal_leggings
loot give @s loot fantasyarsenal:armor/abyssal_boots
