loot give @s loot fantasyarsenal:armor/grave_helmet
loot give @s loot fantasyarsenal:armor/grave_chestplate
loot give @s loot fantasyarsenal:armor/grave_leggings
loot give @s loot fantasyarsenal:armor/grave_boots
