loot give @s loot fantasyarsenal:armor/dawn_helmet
loot give @s loot fantasyarsenal:armor/dawn_chestplate
loot give @s loot fantasyarsenal:armor/dawn_leggings
loot give @s loot fantasyarsenal:armor/dawn_boots
