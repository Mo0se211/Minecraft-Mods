particle minecraft:spore_blossom_air ~ ~1 ~ 0.4 0.5 0.4 0 10
damage @s 2 minecraft:thorns
