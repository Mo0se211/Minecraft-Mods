loot give @s loot fantasyarsenal:armor/tide_helmet
loot give @s loot fantasyarsenal:armor/tide_chestplate
loot give @s loot fantasyarsenal:armor/tide_leggings
loot give @s loot fantasyarsenal:armor/tide_boots
